﻿namespace ManagePatientServices.Models.Request
{
    public class PatientProgressNotesRequest
    {
        public string SectionName { get; set; }
        public string SectionText { get; set; }
    }
}
